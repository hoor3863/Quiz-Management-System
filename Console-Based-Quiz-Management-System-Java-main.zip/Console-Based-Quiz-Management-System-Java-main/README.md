# Console-Based-Quiz-Management-System-Java
The quiz management system is a console-based second-semester university project written in Java, which contains core concepts of Object-oriented programming language. The project contains classes, interfaces, functions, conditional statements, loops, exceptions, and filing. It also contains some .txt files of students, quizzes, attempt lists, answer keys, passwords, and due dates There are primarily two users students and teachers. Key Features:
1.	Create a quiz along with a timer and set the due date
2.	Edit quiz
3.	view students who have attempted
4.	View Feedback
5.	Attempt the quiz within the due date and given time
6.	View attempt history along with details like Id, department, Name, Section, Score, Subjects
7.	View feedback
8.	Send feedback

